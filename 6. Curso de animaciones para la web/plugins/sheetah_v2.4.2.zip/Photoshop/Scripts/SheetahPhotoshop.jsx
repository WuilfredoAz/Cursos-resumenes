/*
 * Sheetah for Photoshop
 * Copyright 2014, Owner: Matthias Guntrum
 *
 *
 */


#target photoshop

app.bringToFront();

function main() {
	// user settings
	var prefs = new Object();
	prefs.sourceFolder         = '~';  // default browse location (default: '~')
	prefs.savePrompt           = true; // display save prompt after import is complete (default: false)
	prefs.closeAfterSave       = true; // close import document after saving (default: false)
	prefs.prettifyFilename     = true; // will create a readable filename

	var fileArray = new Array();
	
	fileArray = File.openDialog('Please select your files:','Allowed Files:*.PNG;*.AVI;*.MOV;*.GIF;*.JPG;*.BMP;*.TIF',true);
	
	var validImages = new Array();
	var validVideos = new Array();

	if (fileArray.length) {

		var validImageFormats = /\.(?:png|gif|jpg|bmp|tif)$/i;
		var validVideoFormats = /\.(?:avi|mov)$/i;

		for(var i =0; i< fileArray.length; i++){
			if(fileArray[i] instanceof File) {

				// store all recognized files into an array
				if (fileArray[i].name.match(validImageFormats)) {
					validImages.push(fileArray[i]);

				}else if (fileArray[i].name.match(validVideoFormats)) {
					validVideos.push(fileArray[i]);
				}
			}
		}

	}

	if(validImages.length){
		importFilesAsLayers(validImages, prefs);
	}

	if(validVideos.length){
		importVideosAsLayers(validVideos, prefs);
	}

	if(!validImages.length && !validVideos.length) {
		alert("The selected folder doesn't contain any recognized images or movie clips.", 'No Files Found', false);
	}

}

function layersToSprite(docRef){

	// --------------------------   
	var numLayers = docRef.artLayers.length; 	

	var cols = parseInt(Math.sqrt(numLayers));
	var rows = Math.ceil(numLayers/cols);
	
 	var spriteX = docRef.width;
 	var spriteY = docRef.height;	
	
	// put things in order
	app.preferences.rulerUnits = Units.PIXELS;
	
	// resize the canvas
 	newX = spriteX * cols;
 	newY = spriteY * rows;
 	
 	docRef.resizeCanvas( newX, newY, AnchorPosition.TOPLEFT );
 	 	
	// move the layers around
 	var rowi = 0;
 	var coli = 0;
 	
 	for (i=(numLayers - 1); i >= 0; i--) 
 	{ 	
 		docRef.artLayers[i].visible = 1;
 		
  		var movX = spriteX*coli;
  		var movY = spriteY*rowi;
  		
 		docRef.artLayers[i].translate(movX, movY);
 		
 		coli++;
 		if (coli > (cols - 1)) 
 		{
	 		rowi++;
	 		coli = 0;
 		}
 	}
}

function prettifyFilename(filename,prefs){
	var n = filename;

	if(prefs.prettifyFilename){
		
		n = n.replace(/(?:\.[^.]*$|$)/, '');
		n = n.replace(/[^\w.]/g, '');
		n = n.replace(/[0-9]/g, '');
		n = n.replace('xpx','');
		n = n.replace('px','');
		n = n.replace('___','_');
		n = n.replace('__','_');

		var seperator = '_';
		if (n.substring(n.length-1) == "_"){
			seperator = '';
	    }
	    n = n + seperator;

	}

	return n;
}

///////////////////////////////////////////////////////////////////////////////
// importVideoAsLayers - imports a folder of images as layers
///////////////////////////////////////////////////////////////////////////////
function importVideosAsLayers(fileArray, prefs) {
	
	for(var i = 0; i<fileArray.length; i++){
		//import video to layers PS HOOK
		var idimportVideoToLayers = stringIDToTypeID( "importVideoToLayers" );
		var desc12 = new ActionDescriptor();
		var idUsng = charIDToTypeID( "Usng" );
		desc12.putPath( idUsng, fileArray[i] );
		executeAction( idimportVideoToLayers, desc12, DialogModes.NO );

		//prettify and append single image pixel values
		var refName = prettifyFilename( fileArray[i].name, prefs );
	    refName = refName + parseInt(activeDocument.width)+'x'+parseInt(activeDocument.height)+'px';

	    //layersToSprite
		layersToSprite(activeDocument);

		//save new document
		saveDoc(activeDocument,prefs,refName);

	}

}

///////////////////////////////////////////////////////////////////////////////
// importFilesAsLayers - imports selected images as layers
///////////////////////////////////////////////////////////////////////////////
function importFilesAsLayers(fileArray, prefs) {
	// create a new document
	var newDoc = open(fileArray[0]);
	var newLayer = newDoc.activeLayer;

	// loop through all files in the source folder
	var refName = '';

	for (var i = 1; i < fileArray.length;  i++) {
		// open document
		var doc = open(fileArray[i]);

		// duplicate to new document
		var layer = doc.activeLayer;
		layer.duplicate(newDoc, ElementPlacement.PLACEATBEGINNING);

		if(i >= fileArray.length-1){

			refName = prettifyFilename(doc.name, prefs);
			refName = refName + parseInt(doc.width)+'x'+parseInt(doc.height)+'px';

		}

		// close imported document
		doc.close(SaveOptions.DONOTSAVECHANGES);
	}

	// reveal all layers
	newDoc.revealAll();

	//layersToSprite
	layersToSprite(newDoc);

	//save new document
	saveDoc(newDoc,prefs,refName);
}

function saveDoc(doc,prefs,refname){
	// save the final document
	if (prefs.savePrompt) {
		// PNG save options
		var saveOptions = new PNGSaveOptions();
			saveOptions.compression = 0;
			saveOptions.interlaced = false;

		//save doc
		var saveFile = new File(prefs.sourceFolder+"/temp/"+refname+".png");
		saveFile = saveFile.saveDlg('Save spritesheet as:');

		if (saveFile) {
			doc.saveAs(saveFile, saveOptions, true, Extension.LOWERCASE);
		}

		// close import document
		if (prefs.closeAfterSave) {
			doc.close(SaveOptions.DONOTSAVECHANGES);
		}
	}
}

///////////////////////////////////////////////////////////////////////////////
// isCorrectVersion - check for Adobe Photoshop CS2 (v9) or higher
///////////////////////////////////////////////////////////////////////////////
function isCorrectVersion() {
	if (parseInt(version, 10) >= 9) {
		return true;
	}
	else {
		alert('This script requires Adobe Photoshop CS2 or higher.', 'Wrong Version', false);
		return false;
	}
}

///////////////////////////////////////////////////////////////////////////////
// showError - display error message if something goes wrong
///////////////////////////////////////////////////////////////////////////////
function showError(err) {
	if (confirm('An unknown error has occurred.\n' +
		'Would you like to see more information?', true, 'Unknown Error')) {
			alert(err + ': on line ' + err.line, 'Script Error', true);
	}
}


// test initial conditions prior to running main function
if (isCorrectVersion()) {
	// remember ruler units; switch to pixels
	var originalRulerUnits = preferences.rulerUnits;
	preferences.rulerUnits = Units.PIXELS;

	try {
		main();
	}
	catch(e) {
		// don't report error on user cancel
		if (e.number != 8007) {
			showError(e);
		}
	}

	// restore original ruler unit
	preferences.rulerUnits = originalRulerUnits;
}
