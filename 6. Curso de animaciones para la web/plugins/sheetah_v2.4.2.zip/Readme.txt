--- Sheetah Spritesheet Tools for After Effects ---


Sheetah turns your composition into a single spritesheet file blazingly fast.
It is targeted for anybody working with spritesheet animations, like 2D/3D Game Artists.

It also features tools to generate custom animation sequences for your spritesheet.


Features:

 - one button goodness
 - export Formats: png, tga, tif
 - alpha channel included
 - optimal calculated dimensions
 - dockable UI panel
 - remembers user settings
 - checks for updates on startup
 - can export to power of 2 texture sizes
 - allows manual distribution between columns and rows

 - Animation Tools for custom animation sequences
 - Animation Sequence export as plain text or in .json format

 - (optional) a Photoshop script to turn image sequences and movies into spritesheets


Rerquirements:

 - Adobe After Effects CS5.5 or newer (tested on CS6 and CC)

 - (optional) Adobe Photoshop CS5.5 or newer (tested on CS6 and CC)


How to install:

	1. Detect your After Effects version. Sheetah comes in two editions for CS and the newer CC versions of After Effects
	
	2. Copy Sheetah's "After Effects/<your version type>/ScriptUI Panels" folder and merge it with your
	   "[your_path_here]/Adobe After Effects/Support Files/Scripts/ScriptUI Panels" folder

	3. Start After Effects, go to Window, and Select "Sheetah.jsx" to open Sheetah's UI panel

	4. Dock the UI panel for more convenience

	5. Choose your desired export format

	6. Enjoy Sheetah!

	------------- (optional) Photoshop script ---------------

	1. Copy Sheetah's "Photoshop/Scripts" folder and merge it with your
	   "[your_path_here]/Adobe Photoshop/Presets/Scripts" folder

	2. Start Photoshop, go to File, Scripts, and select "Sheetah" to start the script

	3. Select an image sequence or a movie file (.mov / .avi) for spritesheet generation


Documentation:

You can find further documentation on:

sheetah.gentlymad.org


------------- Changelog ---------------

2.3 - Sep 17, 2014

- fixed a bug preventing spritesheet export

2.2 - Sep 5, 2014

- fixed a bug, where internet connection was required
- added export option for power of 2 textures
- added option for manual distribution patterns (columns and rows)
- changed spritesheet file name syntax to present more valuable information
- improved custom animation pipeline (including better .json export)
- added support for multiple animations in one composition

1.3 - Mar 3, 2014

- added Version Notifications
- added notifications if max. comp size is exceeded
- added JSON lib for upcoming big changes










